package com.example.merge_test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MergeTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MergeTestApplication.class, args);
	}

}
